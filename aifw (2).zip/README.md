# AIFW — AI Software Engineering Framework

O AIFW é um plano de controle versionado para desenvolvimento de software com agentes. Ele transforma decisões, limites de autonomia, contratos, evidências e qualidade em arquivos e regras executáveis dentro do repositório.

O núcleo é independente do agente. Pi, Claude, Codex ou outro executor entram por adapters; nenhum fornecedor define a Constitution, o lifecycle L0–L3 ou as fontes de verdade do projeto.

> Estado: `v0.1.0`, fundação funcional. O roteamento Luna/Terra/Sol está **desativado e não configurado para execução automática**. Os nomes são aliases substituíveis; a ativação exige avaliações reais e aprovação humana.

## O que já funciona

- Project Intake adaptativo e Project Charter aprovado por humano;
- manifesto com versão do framework fixada por projeto;
- hierarquia executável de Constitution/core, preferências pessoais, capability profiles, stack profiles e regras do projeto;
- lock determinístico de perfis e effective policy compilada;
- classificação de impacto L0–L3 separada da complexidade FAST/WORK/BRAIN;
- `PROJECT_MAP.md` compilado a partir de catálogo e fontes de verdade;
- catálogos globais de decisões que comparam padrões por necessidades, conflitos e trade-offs, com aprovação humana e ADR;
- catálogo global contextual de Clean Code, SOLID, KISS, YAGNI, DRY e separação de responsabilidades, incluindo riscos de uso dogmático;
- quality gates progressivos, distinguindo hard gate, auditoria e aprovação humana;
- máquina de estados para prevenção de impasse e loops de correção;
- política de permissões para Git local/remoto, deploy, serviços externos, delegação e break-glass;
- adapter do Pi com papéis limitados e roteamento recommendation-only por padrão;
- testes de conformidade comportamental do agente;
- profile oficial `flutter-mobile`, com descoberta de `pubspec.yaml`, targets Android/iOS e receitas de gates para Windows e macOS;
- seleção direta de stack no `init` por `--flutter`, `--web` ou `--python`, validada antes de qualquer arquivo ser criado;
- diagnóstico Windows/WSL;
- schemas JSON 2020-12, templates de specs/ADRs/C4/OpenAPI/AsyncAPI, segurança, observabilidade e runbooks;
- CI em Windows e Linux.

## Fluxo de um projeto

```text
DISCOVERY (somente leitura)
        ↓
PROJECT INTAKE → PROJECT CHARTER → aprovação humana
        ↓
RESOLUTION → effective-policy + profile lock
        ↓
RESEARCH → SPEC → TECHNICAL PLAN
        ↓
CHANGE CASE L0–L3 → aprovação quando exigida
        ↓
IMPLEMENTAÇÃO → TESTES → AUDITORIAS → QUALITY GATES
        ↓
PROJECT_MAP + ADRs + contratos + documentação atualizados
```

O agente pode descobrir tecnologia e recomendar a stack. O usuário não precisa saber escolher React, Python, banco de dados ou hosting no primeiro contato. O que precisa vir do humano é intenção, limites, risco e autoridade; consulte [Project Intake](docs/project-intake.md).

## Início rápido

Requisitos: Node.js 22 ou superior e Git. No Windows, PowerShell é o ambiente primário; WSL é um alvo separado de validação, não um lugar para compartilhar `node_modules`.

```powershell
npm ci
npm run check
npm run build
node dist/cli.js --version
```

Para inicializar um projeto:

```powershell
node dist/cli.js init `
  --id meu-projeto `
  --name "Meu Projeto" `
  --flutter `
  --existing `
  --primary windows `
  --targets windows,wsl,linux-ci
```

Depois:

```powershell
node dist/cli.js intake status
node dist/cli.js map check
node dist/cli.js resolve build
node dist/cli.js decision list
node dist/cli.js decision recommend --category application-architecture --signals domain:complex,integrations:many,testability:high --write
node dist/cli.js principle list
node dist/cli.js principle review --signals change:behavior,design:object-oriented --write
node dist/cli.js audit
node dist/cli.js change classify --behavior-change --local-only --reversible
node dist/cli.js validate --level L1
node dist/cli.js eval
node dist/cli.js doctor
```

A CLI não é uma interface que o usuário final precisa operar diariamente. Ela é o **plano de controle** usado pelo agente, pela CI e por automações para produzir resultados determinísticos. Humanos editam Charter/specs/ADRs e aprovam decisões; o agente executa os comandos por trás do fluxo.

No status do intake, `ready` significa que o Charter está pronto para aprovação humana e `complete` significa que o intake inteiro está concluído. A revisão contextual de Clean Code, SOLID e princípios fundamentais aparece em `agentAssessments`: o agente deriva os sinais e executa a próxima ação, sem pedir que o usuário escolha esses princípios como preferência técnica.

## Estrutura

```text
src/core/          regras independentes de fornecedor
src/adapters/      tradução para Pi e futuros agentes
schemas/           contratos JSON Schema 2020-12
policies/          invariantes do framework
profiles/          capacidades e stacks opcionais
decision-catalogs/ padrões globais comparáveis por contexto do projeto
principle-catalogs/ princípios globais para revisão contextual
templates/         ADR, spec, plano, contratos e operações
evals/             casos e traces de conformidade do agente
docs/              arquitetura, políticas e decisões
tests/             testes unitários e workflows ponta a ponta
```

Em um projeto inicializado:

```text
aifw.yaml                       versão, ambiente, perfis e allowlist
.aifw/charter.yaml              decisões humanas e aprovação
.aifw/catalog.yaml              fonte do PROJECT_MAP
.aifw/effective-policy.json     regras resolvidas, geradas
.aifw/framework.lock.yaml       versão e digests fixados
.aifw/gates.yaml                quality gates progressivos
.aifw/permissions.yaml          limites de efeitos colaterais
.aifw/routing.yaml              recommendation-only por padrão
.aifw/decision-cases/           análises e recomendações reproduzíveis
.aifw/decisions/                escolhas aprovadas por humano e ligadas a ADR
.aifw/project-rules.yaml        exceções/regras específicas, opcional
PROJECT_MAP.md                  entrada compilada para humano ou IA
docs/adr/                       decisões arquiteturais
docs/runbooks/                  operação e recuperação
contracts/                      OpenAPI, AsyncAPI e demais contratos
```

## TypeScript, Flutter, Python e WSL

TypeScript foi escolhido para implementar a CLI porque o runtime Node é multiplataforma e o mesmo tipo pode alimentar schemas, adapters e integrações. Isso não limita a stack dos projetos governados: a distribuição inclui profiles Web, Flutter Mobile e Python.

A escolha não aprisiona os projetos: o AIFW pode governar aplicações em Python, Go, Rust ou outras stacks. O formato persistido é YAML/JSON/Markdown e o adapter SDK é pequeno. A decisão completa está em [ADR-0001](docs/decisions/ADR-0001-typescript-cli.md).

WSL é relevante como validação Linux local. Windows e WSL devem manter instalações, caches e `node_modules` separados. Consulte [Windows e WSL](docs/windows-wsl.md).

## Princípios essenciais

1. Uma conversa com IA nunca é fonte de verdade arquitetural.
2. Descoberta precede recomendação; spec precede implementação quando o risco exige.
3. Impacto L0–L3 e potência cognitiva FAST/WORK/BRAIN são eixos diferentes.
4. Toda permissão delegada a um subagente é limitada pelo teto do agente pai.
5. Um gate obrigatório ausente é bloqueio, não aprovação implícita.
6. Exceções expiram, têm escopo, checkpoint e aprovação.
7. Um possível defeito do framework abre impasse; não autoriza o agente a mudar o framework sozinho.
8. Model routing permanece desligado até ser provado por evals e ativado por humano.

## Documentação principal

- [Como usar o AIFW](HOW_TO_USE.md)
- [Constitution](CONSTITUTION.md)
- [Arquitetura](docs/architecture.md)
- [Hierarquia de autoridade](docs/authority.md)
- [Project Intake](docs/project-intake.md)
- [Lifecycle L0–L3](docs/change-lifecycle.md)
- [Prevenção de impasse](docs/impasse-prevention.md)
- [PROJECT_MAP](docs/project-map.md)
- [Quality gates](docs/quality-gates.md)
- [Conformidade do agente](docs/agent-conformance.md)
- [Adapter do Pi](docs/pi-adapter.md)
- [MCPs, skills e extensões](docs/tooling-and-mcps.md)
- [CLI](docs/cli.md)
- [Catálogos de decisões arquiteturais](docs/decision-catalogs.md)
- [Princípios de engenharia](docs/engineering-principles.md)
- [Adoção de projeto existente](docs/existing-project-adoption.md)
- [AGENTS.md e system prompt no Pi](docs/pi-context-files.md)
- [Flutter Mobile](docs/flutter-mobile.md)

## Limite da v0.1

Esta entrega implementa o control plane, seus contratos, exemplos e testes. Ela não instala nem altera automaticamente a configuração pessoal do Pi, não escolhe provedores de produção e não ativa roteamento de modelos. Essas ações exigem um projeto piloto, traces reais, avaliação de custo/qualidade e aprovação humana registrada.

## Licença

MIT. Consulte [LICENSE](LICENSE).
