import type {
  ExtensionAPI,
  ExtensionContext,
} from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { homedir } from "node:os";
import path from "node:path";

import {
  writeCodexHandoff,
  type CodexHandoffInput,
} from "../dist/core/codex-handoff.js";
import {
  loadRoutingPolicyFile,
  loadWorkspaceRouting,
} from "../dist/core/routing-file.js";
import { routeTask, type RoutingTask } from "../dist/core/routing.js";
import { loadWorkspaceManifest } from "../dist/core/workspace.js";

const LEVEL = Type.Union([
  Type.Literal("L0"),
  Type.Literal("L1"),
  Type.Literal("L2"),
  Type.Literal("L3"),
]);
const ROUTE = Type.Union([
  Type.Literal("FAST"),
  Type.Literal("WORK"),
  Type.Literal("BRAIN"),
]);
const OPERATION = Type.Union([
  Type.Literal("single-read"),
  Type.Literal("discovery"),
  Type.Literal("documentation"),
  Type.Literal("implementation"),
  Type.Literal("review"),
  Type.Literal("research"),
  Type.Literal("architecture-decision"),
  Type.Literal("incident-response"),
]);

const ROUTE_PARAMETERS = Type.Object({
  impact: LEVEL,
  operation: OPERATION,
  uncertainty: Type.Union([
    Type.Literal("low"),
    Type.Literal("medium"),
    Type.Literal("high"),
  ]),
  failedAttempts: Type.Optional(Type.Integer({ minimum: 0 })),
  crossDomain: Type.Optional(Type.Boolean()),
  requestedRoute: Type.Optional(ROUTE),
});

const ATTEMPT = Type.Object({
  hypothesis: Type.String(),
  intervention: Type.String(),
  result: Type.String(),
  evidence: Type.Optional(Type.Array(Type.String())),
});

const HANDOFF_PARAMETERS = Type.Object({
  objective: Type.String(),
  reason: Type.String(),
  impact: LEVEL,
  blockerSummary: Type.String(),
  exactError: Type.Optional(Type.String()),
  suspectedCause: Type.Optional(Type.String()),
  attempts: Type.Array(ATTEMPT),
  relevantFiles: Type.Array(Type.String()),
  authoritativeArtifacts: Type.Array(Type.String()),
  constraints: Type.Array(Type.String()),
  verification: Type.Array(Type.String()),
  requestedOutcome: Type.String(),
});

function textResult(text: string, details: unknown) {
  return { content: [{ type: "text" as const, text }], details };
}

async function loadEffectiveRoutingPolicy(cwd: string) {
  try {
    return await loadWorkspaceRouting(cwd);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    return loadRoutingPolicyFile(path.join(homedir(), ".pi", "agent", "aifw-routing.yaml"));
  }
}

export default function aifwExtension(pi: ExtensionAPI) {
  async function routeWithinPi(task: RoutingTask, ctx: ExtensionContext) {
    try {
      const policy = await loadEffectiveRoutingPolicy(ctx.cwd);
      const decision = routeTask(task, {
        aliases: policy.aliases,
        routingEnabled: policy.enabled && policy.mode === "automatic",
      });
      const target = policy.targets[decision.route];
      if (decision.executionMode !== "automatic") {
        return textResult(
          `AIFW recommends ${decision.route}/${decision.suggestedModel}. Automatic switching is not activated, so the current Pi model was preserved.`,
          { decision, switched: false, target },
        );
      }

      const model = ctx.modelRegistry.find(target.provider, target.model);
      if (!model) {
        return textResult(
          `AIFW selected ${decision.route}, but ${target.provider}/${target.model} is unavailable. No silent downgrade was performed.`,
          { decision, switched: false, target, reason: "model-unavailable" },
        );
      }
      const switched = await pi.setModel(model);
      if (!switched) {
        return textResult(
          `AIFW selected ${decision.route}, but Pi could not authenticate ${target.provider}/${target.model}. The current model was preserved.`,
          { decision, switched: false, target, reason: "authentication-unavailable" },
        );
      }
      return textResult(
        `AIFW routed this task to ${decision.route}/${decision.suggestedModel} (${target.model}). Continue the task on the selected model.`,
        { decision, switched: true, target },
      );
    } catch (error) {
      return textResult(
        `AIFW routing is unavailable in this directory: ${error instanceof Error ? error.message : String(error)}`,
        { switched: false, reason: "routing-policy-unavailable" },
      );
    }
  }

  pi.registerTool({
    name: "aifw_route_task",
    label: "AIFW Route Task",
    description:
      "Classify an AIFW task and, only when the persisted routing policy is activated, switch Pi to Luna, Terra or Sol before continuing.",
    promptSnippet:
      "Route AIFW work by impact, operation and uncertainty before making project changes.",
    promptGuidelines: [
      "For an AIFW project, call aifw_route_task once before non-trivial work or before the first mutation.",
      "Call it again only if impact, uncertainty or the task domain materially changes.",
      "Never classify architecture, Constitution, security boundaries or irreversible work below L3/BRAIN.",
      "Repeated failed attempts or high uncertainty require BRAIN.",
    ],
    parameters: ROUTE_PARAMETERS,
    async execute(_toolCallId, params, _signal, _onUpdate, ctx) {
      return routeWithinPi(params, ctx);
    },
  });

  pi.registerTool({
    name: "aifw_codex_handoff",
    label: "AIFW Codex Handoff",
    description:
      "Write a redacted, evidence-oriented Markdown handoff for the user to paste manually into the Codex extension when Pi is blocked or outmatched.",
    promptSnippet:
      "Create a manual Codex fallback handoff after an AIFW impasse or when the user explicitly requests escalation.",
    promptGuidelines: [
      "Use aifw_codex_handoff after the distinct-attempt limit, a framework conflict, or an explicit request to escalate to Codex.",
      "Include verbatim errors, genuinely distinct attempts, relevant files, sources of truth and fresh verification requirements.",
      "Never put secrets in a handoff and never claim that creating the handoff sends anything to Codex.",
    ],
    parameters: HANDOFF_PARAMETERS,
    async execute(_toolCallId, params, _signal, _onUpdate, ctx) {
      try {
        const manifest = await loadWorkspaceManifest(ctx.cwd);
        const input: CodexHandoffInput = {
          project: { id: manifest.metadata.id, name: manifest.metadata.name },
          objective: params.objective,
          reason: params.reason,
          impact: params.impact,
          suggestedRoute: "BRAIN",
          blocker: {
            summary: params.blockerSummary,
            ...(params.exactError === undefined ? {} : { exactError: params.exactError }),
            ...(params.suspectedCause === undefined
              ? {}
              : { suspectedCause: params.suspectedCause }),
          },
          attempts: params.attempts,
          relevantFiles: params.relevantFiles,
          authoritativeArtifacts: params.authoritativeArtifacts,
          constraints: params.constraints,
          verification: params.verification,
          requestedOutcome: params.requestedOutcome,
        };
        const result = await writeCodexHandoff(ctx.cwd, input);
        return textResult(
          `Codex handoff written to ${result.relativePath}. It was not sent anywhere; give this path to the user so they can review and paste it into Codex.`,
          { path: result.relativePath, transfer: "manual" },
        );
      } catch (error) {
        return textResult(
          `Could not create the Codex handoff: ${error instanceof Error ? error.message : String(error)}`,
          { reason: "handoff-failed" },
        );
      }
    },
  });

  pi.registerCommand("aifw-routing", {
    description: "Show AIFW routing policy and current Pi model",
    handler: async (_args, ctx) => {
      try {
        const policy = await loadEffectiveRoutingPolicy(ctx.cwd);
        const current = ctx.model ? `${ctx.model.provider}/${ctx.model.id}` : "none";
        ctx.ui.notify(
          `AIFW routing: ${policy.mode}; current: ${current}; FAST=${policy.targets.FAST.model}, WORK=${policy.targets.WORK.model}, BRAIN=${policy.targets.BRAIN.model}`,
          "info",
        );
      } catch (error) {
        ctx.ui.notify(
          `AIFW routing unavailable: ${error instanceof Error ? error.message : String(error)}`,
          "warning",
        );
      }
    },
  });

  pi.registerCommand("aifw-route", {
    description: "Route now: /aifw-route <L0-L3> <operation> <low|medium|high> [failedAttempts]",
    handler: async (args, ctx) => {
      const [impact, operation, uncertainty, failedAttempts = "0"] = args.trim().split(/\s+/u);
      const impacts = ["L0", "L1", "L2", "L3"] as const;
      const operations: RoutingTask["operation"][] = [
        "single-read",
        "discovery",
        "documentation",
        "implementation",
        "review",
        "research",
        "architecture-decision",
        "incident-response",
      ];
      const uncertainties = ["low", "medium", "high"] as const;
      const count = Number.parseInt(failedAttempts, 10);
      if (
        !impacts.includes(impact as (typeof impacts)[number]) ||
        !operations.includes(operation as RoutingTask["operation"]) ||
        !uncertainties.includes(uncertainty as (typeof uncertainties)[number]) ||
        !Number.isInteger(count) ||
        count < 0
      ) {
        ctx.ui.notify(
          "Usage: /aifw-route <L0-L3> <operation> <low|medium|high> [failedAttempts]",
          "warning",
        );
        return;
      }
      const result = await routeWithinPi(
        {
          impact: impact as RoutingTask["impact"],
          operation: operation as RoutingTask["operation"],
          uncertainty: uncertainty as RoutingTask["uncertainty"],
          failedAttempts: count,
        },
        ctx,
      );
      const message = result.content[0];
      ctx.ui.notify(message?.type === "text" ? message.text : "AIFW routing completed.", "info");
    },
  });

  pi.registerCommand("codex-handoff", {
    description: "Ask Pi to generate a manual AIFW handoff for the Codex extension",
    handler: async (args) => {
      const focus = args.trim() || "resolve the current blocker";
      pi.sendUserMessage(
        `Generate a manual Codex fallback handoff focused on: ${focus}. First gather the exact blocker, distinct attempts, evidence, relevant files, authoritative artifacts, constraints and verification criteria. Then call aifw_codex_handoff. Do not continue implementation after producing the handoff.`,
        { deliverAs: "followUp" },
      );
    },
  });
}
