# AGENTS.md, SYSTEM.md e instruções globais no Pi

## AGENTS.md

`AGENTS.md` acrescenta contexto e instruções sem substituir a identidade e as ferramentas padrão do Pi. O Pi carrega o arquivo global `~/.pi/agent/AGENTS.md` e também arquivos `AGENTS.md` ou `CLAUDE.md` encontrados nos diretórios pai e no diretório atual.

Use para preferências gerais, segurança, estilo de colaboração, comandos obrigatórios e regras de trabalho. Para instruções pessoais que devem funcionar com ou sem AIFW, o local recomendado é:

```text
~/.pi/agent/AGENTS.md
```

No Windows, `~` corresponde ao diretório do usuário, normalmente `C:\Users\<usuario>`.

## SYSTEM.md

`.pi/SYSTEM.md` no projeto ou `~/.pi/agent/SYSTEM.md` global substitui o system prompt padrão do Pi. Isso é apropriado quando se deseja transformar o Pi em outro tipo de agente, mas é arriscado para preferências comuns porque pode remover instruções padrão importantes do coding agent.

Para acrescentar instruções no nível do system prompt sem substituir o padrão, o Pi oferece `.pi/APPEND_SYSTEM.md` no projeto ou `~/.pi/agent/APPEND_SYSTEM.md` global.

## Recomendação

- Preferências gerais independentes do framework: `~/.pi/agent/AGENTS.md`.
- Regras específicas do repositório: `AGENTS.md` na raiz do projeto.
- Complemento realmente necessário ao system prompt: `APPEND_SYSTEM.md`.
- Substituição total de personalidade/função do agente: `SYSTEM.md`, somente de forma deliberada.

Após alterar esses arquivos, reinicie o Pi ou use `/reload`. O carregamento de `AGENTS.md`/`CLAUDE.md` pode ser desativado com `--no-context-files`.

Fontes oficiais: documentação de uso e README do Pi Coding Agent no repositório `badlogic/pi-mono`.
