# Fallback manual do Pi para Codex

O fallback existe para quando o Pi atinge o limite de tentativas distintas, identifica conflito estrutural, não possui capacidade suficiente ou recebe pedido explícito do usuário. Ele **não envia dados automaticamente** ao Codex: gera Markdown local, o humano revisa e cola no Codex Extension.

## No Pi

Use:

```text
/codex-handoff corrigir o bloqueio atual sem enfraquecer o framework
```

O comando pede ao agente para reunir erro exato, tentativas realmente distintas, evidências, arquivos, fontes de verdade, restrições e critérios de verificação. O agente conclui chamando `aifw_codex_handoff`, que grava o arquivo em `.aifw/handoffs/`.

Também é possível pedir em linguagem natural: “gere um handoff para o Codex”. A transferência continua manual.

## Pela CLI

Preencha uma cópia de `templates/codex-handoff-input.json` e execute:

```powershell
aifw handoff codex --input .aifw/handoff-input.json --json
```

A saída informa o caminho criado. O renderer remove padrões comuns de secrets e impede que `--output` escape da raiz do projeto. Isso é defesa adicional, não permissão para incluir credenciais na entrada.

## Contrato de retorno

Codex deve devolver diagnóstico, alterações, decisões/ADRs afetados, comandos e resultados de verificação, riscos remanescentes e instruções claras para o Pi continuar. O handoff não amplia autorização para push, deploy, produção, destruição ou mudança da Constitution.
