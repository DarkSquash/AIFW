# Windows, WSL e escolha TypeScript/Python

## Papel de cada ambiente

Windows/PowerShell é o ambiente primário atual. WSL é relevante como alvo secundário de validação Linux, especialmente para diferenças de path, permissões, case sensitivity, scripts e ferramentas usadas pela CI.

WSL não deve compartilhar `node_modules`, virtualenv ou cache de package manager com Windows. Cada ambiente instala dependências a partir do mesmo lockfile e executa os gates aplicáveis. O código-fonte pode ser comum; artefatos dependentes de plataforma não.

O mesmo isolamento vale para Flutter: Windows e WSL precisam de instalações e caches próprios do SDK. Um Flutter instalado apenas no Windows não torna `flutter` executável dentro do WSL. Para um app Android+iOS, Windows pode executar formatter, analyzer, testes e build Android; build iOS exige executor macOS com Xcode e não pode ser substituído por um resultado Android bem-sucedido.

`aifw doctor` verifica Node e Git primários e, no Windows, consulta WSL separadamente. Falha de acesso ao serviço WSL é reportada como indisponibilidade do alvo secundário sem fingir que Node/Git do Windows falharam.

## Por que TypeScript na CLI

Para esta v0.1, TypeScript é a melhor escolha prática:

- combina com o primeiro profile Web TypeScript;
- roda igual em Windows, WSL e CI Linux;
- compartilha tipos entre core, CLI e adapters;
- integra naturalmente JSON Schema, YAML e tooling Web;
- gera um pacote único via npm.

Python seria melhor se o núcleo dependesse de ciência de dados, ML, notebooks, transformação pesada ou bibliotecas exclusivas do ecossistema. Nada impede profiles, gates e adapters Python; projetos governados pelo AIFW não precisam ser TypeScript.

A troca futura do executável é possível porque Constitution, schemas e documentos são portáveis. Não seria “sem custo”: haveria migração do CLI/SDK e paridade de testes. Por isso a linguagem está registrada em ADR, e não tratada como decisão descartável.

## Matriz recomendada

| Contexto | Validação |
| --- | --- |
| desenvolvimento cotidiano | Windows |
| compatibilidade local Linux | WSL, quando disponível |
| merge/release | Windows + Ubuntu em CI |

Não declare compatibilidade WSL se a validação não rodou; registre `not-run` com o motivo.

## Gate runner no Windows

O executor resolve os shims `flutter.cmd`/`flutter.bat` e `dart.cmd`/`dart.bat` encontrados no `PATH` e os inicia por um processador de comandos explícito, com shell implícito desativado para os demais gates. Isso evita o `spawn EINVAL` comum ao tentar iniciar um batch diretamente com `execFile` e preserva stdout/stderr como evidência.
