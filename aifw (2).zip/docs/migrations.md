# Versionamento e migrations

Cada `aifw.yaml` fixa `frameworkVersion`; `latest`, ranges e atualização silenciosa são inválidos. `.aifw/framework.lock.yaml` fixa profiles e digests resolvidos.

## Atualização

1. ler release notes e breaking changes;
2. criar Change Case — L2 por padrão, L3 se core/Constitution/security mudar;
3. gerar checkpoint e plano de rollback;
4. executar migration explícita em branch/worktree;
5. regenerar effective policy, lock e PROJECT_MAP;
6. atualizar schemas/templates/ADRs necessários;
7. executar testes, conformance evals e matriz Windows/Linux;
8. aprovar e atualizar `frameworkVersion` somente após evidência.

## Regras

- migration é idempotente ou detecta que já foi aplicada;
- nunca sobrescreve decisão humana sem conflito explícito;
- mantém backup/checkpoint recuperável;
- dry-run lista arquivos e alterações;
- falha parcial deixa instrução de recovery;
- downgrade só é prometido quando testado.

Aprendizado de um projeto vira default apenas por RFC/ADR, evidência em contextos diferentes e aprovação. Até lá permanece project rule ou waiver local.
