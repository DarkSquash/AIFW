# Adapter do Pi e subagentes

## Estado atual

O pacote inclui a extensão executável `extensions/aifw.ts`. Ela registra `aifw_route_task`, chama `pi.setModel()` e usa os alvos persistidos na policy. A instalação de referência foi ativada em 2026-08-23 após 32 casos, 100% de aprovação, zero falhas críticas e aprovação humana registrada no ADR-0008.

O **default do framework** continua seguro: todo projeto novo nasce com `enabled: false` e `mode: recommendation-only`. Policy do projeto vence a global; fora de um projeto AIFW, a extensão consulta `~/.pi/agent/aifw-routing.yaml`.

## Papéis

O adapter publica seis papéis:

| Papel | Responsabilidade |
| --- | --- |
| orchestrator | dividir trabalho, manter lifecycle e consolidar evidência |
| researcher | coletar fontes e incertezas sem mudar o projeto |
| architect | avaliar boundaries, contratos e decisões L2/L3 |
| implementer | executar Change Case aprovado |
| reviewer | revisar correção, regressão e riscos de forma independente |
| auditor | avaliar policies/gates e produzir findings |

Papéis começam sem capabilities implícitas. Cada tarefa recebe apenas as permissões declaradas, e um subagente nunca supera o teto de capabilities do pai. O orchestrator continua responsável pela conclusão; delegar não transfere aprovação humana.

## Roteamento pretendido

| Classe | Alias inicial | Uso típico |
| --- | --- | --- |
| FAST | Luna | leitura única, classificação simples, docs/discovery de baixa incerteza |
| WORK | Terra | implementação, testes, revisão e pesquisa comuns |
| BRAIN | Sol | arquitetura, L3, alta incerteza, impasse ou falhas repetidas |

Aliases não são competências garantidas. Podem apontar para outros modelos. L3 sempre recomenda BRAIN; uma tarefa L0 semanticamente difícil também pode usar BRAIN. O impacto continua L0.

## Ativação

`aifw route activate` aceita relatório de conformidade e exige identidade + ADR/registro. O core recusa ativação com menos de 30 casos, pass rate abaixo de 95%, falha crítica ou aprovação ausente. Ativação escreve evidência em routing policy; não fica em conversa.

`aifw route eval --output <report.json>` executa a suíte determinística revisável. O modelo alvo indisponível ou sem autenticação não é substituído silenciosamente: a extensão preserva o modelo atual e retorna erro explícito.

## Uso no Pi

- `/aifw-routing`: estado da policy, modelo atual e alvos;
- `/aifw-route L2 implementation medium`: classificação/troca manual e diagnosticável;
- `aifw_route_task`: ferramenta chamada pelo agente antes de trabalho não trivial;
- `/codex-handoff <foco>`: solicita handoff manual para Codex;
- `aifw_codex_handoff`: grava o Markdown em `.aifw/handoffs/`.

## Extensões do Pi

`pi-subagents` serve para executar os papéis limitados. Uma extensão de workflows paralela é dispensável enquanto o framework já coordena lifecycle. Structured return pode ser adotado se reduzir erros do adapter, mas o contrato canônico continua sendo o adapter SDK e os schemas do repositório.
