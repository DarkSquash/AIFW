# Referência gerada da CLI do AIFW

> Arquivo gerado por `npm run docs:generate`. Não edite manualmente. O guia com explicações e fluxos está em [HOW_TO_USE.md](../HOW_TO_USE.md).

Esta referência contém 22 comandos finais e suas opções, extraídos da implementação atual.

## `aifw --help`

```text
Usage: aifw [options] [command]

AI Software Engineering Framework control plane

Options:
  -V, --version       output the version number
  -h, --help          display help for command

Commands:
  init [options]      initialize the framework control plane in a project
  audit [options]     inspect a project without changing it
  intake              assess and approve the human Project Charter decisions
  map                 compile and verify PROJECT_MAP.md
  decision            compare and record project-wide architecture decisions
  principle           review Clean Code, SOLID and foundational principles
                      contextually
  resolve             resolve authority layers into a pinned effective policy
  change              classify change impact
  route               explain cognitive routing
  handoff             create structured manual handoffs for another executor
  doctor [options]    check Node, Git, Windows and WSL
  eval [options]      run agent behavioral conformance fixtures
  validate [options]  run quality gates selected by L0-L3 impact
  help [command]      display help for command
```

## `aifw init`

```text
Usage: aifw init [options]

initialize the framework control plane in a project

Options:
  --id <id>                 stable project id
  --name <name>             human-readable project name
  --existing                initialize an existing codebase
  --flutter                 use the Flutter mobile profile
  --web                     use the Web profile for React, JavaScript,
                            TypeScript and related stacks
  --python                  use the Python profile
  --locale <locale>         project language (default: "pt-BR")
  --primary <environment>   primary environment (default: "windows")
  --targets <environments>  comma-separated validation targets (default:
                            "windows,wsl,linux-ci")
  --json                    emit stable machine-readable JSON
  -h, --help                display help for command
```

## `aifw audit`

```text
Usage: aifw audit [options]

inspect a project without changing it

Options:
  --json      emit stable machine-readable JSON
  -h, --help  display help for command
```

## `aifw intake status`

```text
Usage: aifw intake status [options]

show missing human decisions and agent-owned technical assessments

Options:
  --json      emit stable machine-readable JSON
  -h, --help  display help for command
```

## `aifw intake approve`

```text
Usage: aifw intake approve [options]

persist explicit human approval of a ready charter

Options:
  --by <identity>   human approver identity
  --at <timestamp>  ISO-8601 approval timestamp
  --json            emit stable machine-readable JSON
  -h, --help        display help for command
```

## `aifw map build`

```text
Usage: aifw map build [options]

regenerate PROJECT_MAP.md

Options:
  --json      emit stable machine-readable JSON
  -h, --help  display help for command
```

## `aifw map check`

```text
Usage: aifw map check [options]

check PROJECT_MAP.md freshness

Options:
  --json      emit stable machine-readable JSON
  -h, --help  display help for command
```

## `aifw decision list`

```text
Usage: aifw decision list [options]

list available decision categories and alternatives

Options:
  --category <id>  filter by decision category
  --json           emit stable machine-readable JSON
  -h, --help       display help for command
```

## `aifw decision recommend`

```text
Usage: aifw decision recommend [options]

rank alternatives from explicit project signals

Options:
  --category <id>      decision category
  --signals <signals>  comma-separated project signals
  --selected <ids>     comma-separated decisions already selected (default: "")
  --write              persist the reviewable decision case
  --json               emit stable machine-readable JSON
  -h, --help           display help for command
```

## `aifw decision approve`

```text
Usage: aifw decision approve [options]

accept an eligible alternative using human approval and an ADR

Options:
  --category <id>   decision category
  --option <id>     selected alternative
  --by <identity>   human approver identity, prefixed human:
  --adr <path>      existing ADR path inside the project
  --at <timestamp>  ISO-8601 approval timestamp
  --json            emit stable machine-readable JSON
  -h, --help        display help for command
```

## `aifw principle list`

```text
Usage: aifw principle list [options]

list engineering principles and their applicability signals

Options:
  --family <family>  clean-code, solid or foundational
  --json             emit stable machine-readable JSON
  -h, --help         display help for command
```

## `aifw principle review`

```text
Usage: aifw principle review [options]

build a contextual engineering-principle checklist

Options:
  --signals <signals>  comma-separated project or change signals
  --write              persist the review under .aifw/reviews
  --json               emit stable machine-readable JSON
  -h, --help           display help for command
```

## `aifw resolve build`

```text
Usage: aifw resolve build [options]

write the effective policy and framework lock

Options:
  --personal <path>  optional personal defaults PolicySet
  --json             emit stable machine-readable JSON
  -h, --help         display help for command
```

## `aifw resolve check`

```text
Usage: aifw resolve check [options]

verify the committed effective policy and lock

Options:
  --personal <path>  optional personal defaults PolicySet
  --json             emit stable machine-readable JSON
  -h, --help         display help for command
```

## `aifw change classify`

```text
Usage: aifw change classify [options]

Options:
  --read-only
  --docs-only
  --behavior-change
  --local-only
  --reversible
  --cross-module
  --shared-contract
  --sensitive-data
  --global-design-system
  --external-cost
  --production
  --touches-auth
  --framework-core
  --constitution
  --security-boundary
  --destructive-migration
  --breaking-contract
  --irreversible-production
  --complexity <route>       fast, work or brain
  --json                     emit stable machine-readable JSON
  -h, --help                 display help for command
```

## `aifw route explain`

```text
Usage: aifw route explain [options]

Options:
  --impact <level>           L0, L1, L2 or L3
  --operation <operation>
  --uncertainty <level>      low, medium or high
  --failed-attempts <count>  number of previous failures (default: "0")
  --cross-domain
  --json                     emit stable machine-readable JSON
  -h, --help                 display help for command
```

## `aifw route status`

```text
Usage: aifw route status [options]

show persisted routing state

Options:
  --json      emit stable machine-readable JSON
  -h, --help  display help for command
```

## `aifw route eval`

```text
Usage: aifw route eval [options]

evaluate deterministic routing against reviewable cases

Options:
  --cases <path>   routing case fixture
  --output <path>  write the JSON activation report
  --json           emit stable machine-readable JSON
  -h, --help       display help for command
```

## `aifw route activate`

```text
Usage: aifw route activate [options]

activate routing after passing evals and human approval

Options:
  --report <path>       JSON conformance report
  --by <identity>       human approver identity
  --record <reference>  persisted ADR or approval record
  --json                emit stable machine-readable JSON
  -h, --help            display help for command
```

## `aifw handoff codex`

```text
Usage: aifw handoff codex [options]

write a redacted Markdown handoff for manual transfer to Codex

Options:
  --input <path>   structured handoff JSON
  --output <path>  project-relative Markdown output path
  --json           emit stable machine-readable JSON
  -h, --help       display help for command
```

## `aifw doctor`

```text
Usage: aifw doctor [options]

check Node, Git, Windows and WSL

Options:
  --json      emit stable machine-readable JSON
  -h, --help  display help for command
```

## `aifw eval`

```text
Usage: aifw eval [options]

run agent behavioral conformance fixtures

Options:
  --cases <path>   case directory
  --traces <path>  trace directory
  --json           emit stable machine-readable JSON
  -h, --help       display help for command
```

## `aifw validate`

```text
Usage: aifw validate [options]

run quality gates selected by L0-L3 impact

Options:
  --level <level>  L0, L1, L2 or L3
  --json           emit stable machine-readable JSON
  -h, --help       display help for command
```
