# Adoção de um projeto existente

## Inicialização

Execute na raiz real do projeto:

```powershell
aifw init --id app --name "Projeto" --existing --flutter
```

Troque `--flutter` por `--web` ou `--python`; omita a flag quando o agente ainda precisar recomendar a stack.

O `init --existing` cria o control plane sem alterar o código da aplicação: manifesto, Charter, catálogo inicial, permissions, gates, routing, diretórios de ADR/contratos/runbooks e o primeiro `PROJECT_MAP.md`.

## Levantamento e documentação

Depois da inicialização, o fluxo correto é:

1. executar `aifw audit --json` para descoberta somente leitura;
2. o agente inspecionar entrypoints, módulos, dependências internas, fluxos, contratos, dados, integrações, CI, deploy e documentação existente;
3. registrar apenas fatos confirmados em `.aifw/catalog.yaml`;
4. criar ou atualizar `docs/architecture.md`, ADRs, contratos e runbooks necessários;
5. executar `aifw map build` para recompilar `PROJECT_MAP.md`;
6. executar `aifw resolve build` para fixar profiles e policy efetiva;
7. executar `aifw audit`, `aifw map check` e o nível adequado de `aifw validate`.

## Limite atual da v0.1

`audit` detecta stack, comandos, dependências de pacote, contratos, CI, ADRs e targets Flutter, mas é deliberadamente somente leitura. `map build` não faz descoberta: ele compila `.aifw/catalog.yaml`.

Portanto, a compreensão semântica de módulos, responsabilidades e relações ainda é uma etapa assistida pelo agente e revisada pelo humano. O AIFW não deve inventar arquitetura a partir de nomes de pastas. Uma futura operação de adoção pode persistir um inventário factual automaticamente, mas relações semânticas continuarão exigindo evidência e revisão.

## Prompt recomendado ao agente

```text
Adote este repositório existente no AIFW. Faça primeiro discovery somente leitura.
Execute aifw audit, identifique fontes de verdade, entrypoints, módulos,
dependências internas, contratos, dados, integrações, CI e deploy. Não infira
responsabilidades apenas pelo nome das pastas. Mostre dúvidas e conflitos antes
de persistir. Depois atualize .aifw/catalog.yaml e docs/architecture.md, registre
decisões existentes como ADR quando houver evidência, execute aifw map build,
aifw resolve build e valide o resultado.
```
