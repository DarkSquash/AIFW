<!-- aifw:project-map digest=08d7d2350332def3f53cdfdc06f24ee181e5859c1ee214d2a17931df34ae38f4 -->
# PROJECT_MAP — AI Software Engineering Framework

> Compiled entrypoint. Edit authoritative sources, then regenerate this file.

## Project

| Field | Value |
| --- | --- |
| Project ID | aifw |
| Framework | 0.1.0 |
| Verified revision | working-tree |

## Purpose

Tornar desenvolvimento com agentes reproduzível, seguro e independente de fornecedor por meio de decisões e evidências versionadas.

## Sources of truth

| Topic | Source |
| --- | --- |
| Arquitetura | docs/architecture.md |
| Catálogo de princípios de engenharia | principle-catalogs/ |
| Catálogos de decisão | decision-catalogs/ |
| Comportamento verificado | tests/ |
| Constituição | CONSTITUTION.md |
| Contrato do pacote | package.json |
| Contratos de documento | schemas/ |
| Decisões | docs/decisions/ |
| Guia operacional | HOW_TO_USE.md |
| Intenção do produto | .aifw/charter.yaml |
| Regras core | policies/core.yaml |

## Catalog

| ID | Kind | Name | Owner | Visibility | Source | Description |
| --- | --- | --- | --- | --- | --- | --- |
| component:adapter-sdk | Component | Agent Adapter SDK | framework:adapters | public | src/adapters/sdk.ts | Contrato tipado para traduzir tarefas sem redefinir governança. |
| component:cli | Component | Control-plane CLI | framework:core | public | src/cli.ts | Interface determinística usada por agentes, humanos e CI. |
| component:conformance | Component | Agent conformance evaluator | framework:quality | public | src/core/conformance.ts | Avalia traces contra eventos, ordem, aprovações e evidência esperados. |
| component:core | Component | Vendor-neutral core | framework:core | public | src/core/ | Intake, authority, lifecycle, gates, map, permissions, impasse, routing e conformance. |
| component:decision-engine | Component | Architecture decision engine | framework:core | public | src/core/decision-catalog.ts | Classifica alternativas, expõe incerteza e exige aprovação humana com ADR antes de registrar uma escolha. |
| component:pi-adapter | Component | Pi adapter | framework:adapters | public | src/adapters/pi.ts | Papéis limitados e plano recommendation-only para Pi. |
| component:principle-review | Component | Contextual principle review | framework:quality | public | src/core/principle-catalog.ts | Produz checklists determinísticos sem transformar heurísticas de design em regras universais rígidas. |
| contract:schemas | Contract | Framework document schemas | framework:core | public | schemas/ | JSON Schema 2020-12 para documentos públicos do AIFW. |
| decision:agent-independent-core | Decision | Core independente do agente | human:owner | public | docs/decisions/ADR-0002-agent-independent-core.md | Governança não depende do executor ou fornecedor. |
| profile:flutter-mobile | Resource | Flutter Mobile profile | framework:profiles | public | profiles/flutter-mobile/ | Regras e receitas de gates para Dart, Flutter, Android e iOS sem impor arquitetura de pastas ou biblioteca de estado. |
| profile:python | Resource | Python profile | framework:profiles | public | profiles/python/ | Regras portáveis de lint, formato, testes, dependências, segurança e observabilidade para projetos Python. |
| profile:web | Resource | Web profile | framework:profiles | public | profiles/web-ts/ | Regras de arquitetura, contratos, design, segurança e observabilidade para React, JavaScript, TypeScript e outras stacks Web. |
| resource:decision-catalogs | Resource | Global decision catalogs | framework:architecture | public | decision-catalogs/ | Alternativas arquiteturais comparáveis por sinais explícitos, com conflitos, trade-offs e fontes. |
| resource:evals | Resource | Conformance fixtures | framework:quality | public | evals/ | Casos e traces de fumaça para validar o evaluator. |
| resource:how-to-use | Resource | AIFW operational guide | framework:docs | public | HOW_TO_USE.md | Instalação, fluxos recomendados, referência completa da CLI e comandos da extensão do Pi. |
| resource:policies | Resource | Core policies | framework:governance | public | policies/core.yaml | Invariantes executáveis alinhados à Constitution. |
| resource:principle-catalogs | Resource | Engineering principle catalogs | framework:quality | public | principle-catalogs/ | Clean Code, SOLID e princípios fundamentais aplicados por sinais, perguntas, evidências, exceções e riscos de mau uso. |
| resource:profiles | Resource | Optional profiles | framework:profiles | public | profiles/ | Capability e stack rules selecionadas após intake/discovery. |
| runtime:node | Runtime | Node.js | framework:runtime | public | package.json | Runtime multiplataforma do control plane, versão 22 ou superior. |
| system:aifw | System | AIFW | human:owner | public | CONSTITUTION.md | Framework independente de agente para governança e execução verificável de engenharia de software. |

## Relationships

| Source | Relation | Target |
| --- | --- | --- |
| component:adapter-sdk | dependsOn | component:core |
| component:adapter-sdk | partOf | system:aifw |
| component:cli | dependsOn | component:core |
| component:cli | documentedBy | resource:how-to-use |
| component:cli | partOf | system:aifw |
| component:conformance | consumes | resource:evals |
| component:conformance | partOf | component:core |
| component:core | partOf | system:aifw |
| component:core | provides | contract:schemas |
| component:decision-engine | consumes | resource:decision-catalogs |
| component:decision-engine | partOf | component:core |
| component:pi-adapter | dependsOn | component:adapter-sdk |
| component:pi-adapter | partOf | system:aifw |
| component:principle-review | consumes | resource:principle-catalogs |
| component:principle-review | partOf | component:core |
| contract:schemas | partOf | system:aifw |
| decision:agent-independent-core | partOf | system:aifw |
| profile:flutter-mobile | dependsOn | component:core |
| profile:flutter-mobile | partOf | resource:profiles |
| profile:python | dependsOn | component:core |
| profile:python | partOf | resource:profiles |
| profile:web | dependsOn | component:core |
| profile:web | partOf | resource:profiles |
| resource:decision-catalogs | partOf | system:aifw |
| resource:evals | partOf | system:aifw |
| resource:how-to-use | partOf | system:aifw |
| resource:policies | partOf | system:aifw |
| resource:principle-catalogs | partOf | system:aifw |
| resource:profiles | dependsOn | resource:policies |
| resource:profiles | partOf | system:aifw |
| system:aifw | documentedBy | decision:agent-independent-core |
| system:aifw | runsOn | runtime:node |
