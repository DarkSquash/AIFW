# Python profile

Profile geral para aplicações, serviços, automações e sistemas de dados em Python. Ele respeita o gerenciador de ambiente, linter, formatter, test runner e type checker declarados pelo próprio repositório, sem impor Django, FastAPI, Flask, Ruff, Black, pytest, uv, Poetry ou outra ferramenta universalmente.

Ative durante a inicialização com `aifw init --python`.
