# Como usar o AIFW

Este é o guia operacional do AIFW v0.1.0 para Windows/PowerShell, Pi Agent e projetos novos ou existentes. A CLI é um plano de controle: normalmente o agente executa os comandos e o humano fornece contexto, revisa propostas e concede aprovações explícitas.

## Entenda as duas instalações

O AIFW possui duas partes relacionadas, mas diferentes:

1. **Pacote do Pi:** carrega a extensão `extensions/aifw.ts`, o roteamento e o handoff para Codex.
2. **CLI `aifw`:** inicializa projetos, compila policies, atualiza o mapa e executa validações.

Instalar o pacote com `pi install` não garante sozinho que o comando `aifw` ficará disponível no PowerShell. Para isso, use `npm link` ou execute `dist/cli.js` diretamente.

## Preparar o AIFW pela primeira vez

Na pasta do próprio AIFW:

```powershell
Set-Location "C:\caminho\para\aifw"
npm ci
npm run check
npm run build
npm link
pi install "C:\caminho\para\aifw"
```

Depois, reinicie o Pi ou execute `/reload` dentro dele. Confirme:

```powershell
aifw --version
pi list
```

Se não quiser usar `npm link`, substitua qualquer exemplo deste guia por:

```powershell
node "C:\caminho\para\aifw\dist\cli.js" --version
```

Por exemplo, `aifw doctor` equivale a:

```powershell
node "C:\caminho\para\aifw\dist\cli.js" doctor
```

## O que significa “a instalação referencia o repositório local”

Quando você executa:

```powershell
pi install "C:\Projetos\aifw"
```

o Pi registra `C:\Projetos\aifw` como origem local do pacote. Ele não publica nem transforma essa pasta em um pacote independente na internet. Isso produz três consequências:

- editar e recompilar o AIFW naquela pasta atualiza a instalação após `/reload`;
- apagar, mover ou renomear a pasta torna o caminho registrado inválido;
- mover a pasta não perde o framework: basta registrar o caminho novo.

Depois de mover a pasta:

```powershell
pi list
pi remove "C:\caminho\antigo\aifw"
Set-Location "C:\caminho\novo\aifw"
npm link
pi install "C:\caminho\novo\aifw"
```

Use no `pi remove` exatamente a origem mostrada por `pi list`. Depois execute `/reload`. Enquanto a pasta não for movida, não é necessário reinstalar a cada mudança: execute `npm run build` e `/reload`.

## Atualizar o AIFW sem mudar sua pasta

```powershell
Set-Location "C:\caminho\para\aifw"
npm ci
npm run check
npm run build
```

Depois use `/reload` no Pi. `npm ci` sincroniza dependências com o lockfile; `npm run check` executa tipagem, lint e testes; `npm run build` atualiza `dist/`, que é carregado pela extensão.

## Primeiro uso em um projeto Flutter existente

Abra o PowerShell na raiz do projeto, onde está o `pubspec.yaml`:

```powershell
Set-Location "C:\caminho\para\meu_app"
aifw init --id meu-app --name "Meu App" --flutter --existing
aifw doctor
aifw audit --json
aifw intake status --json
```

Em seguida, peça ao Pi:

```text
Adote este projeto Flutter existente usando o AIFW. Faça discovery somente
leitura, execute o intake, pergunte apenas as decisões humanas ausentes,
derive as avaliações técnicas do agente, documente fatos confirmados no
catálogo e na arquitetura, atualize PROJECT_MAP e effective policy e execute
os gates proporcionais ao impacto. Não invente responsabilidades a partir
apenas dos nomes das pastas.
```

O `init` não reorganiza o código Flutter nem escolhe automaticamente Riverpod, Bloc, Clean Architecture ou outra arquitetura. Ele cria o plano de controle. O agente analisa o projeto e usa os catálogos de decisão para recomendar padrões conforme necessidade, trade-offs e evidências.

## Primeiro uso em outros projetos

Projeto Web/React/JavaScript/TypeScript existente:

```powershell
aifw init --id meu-site --name "Meu Site" --web --existing
```

Projeto Python existente:

```powershell
aifw init --id minha-api --name "Minha API" --python --existing
```

Projeto novo:

```powershell
aifw init --id novo-produto --name "Novo Produto" --web
```

Se a stack ainda não foi decidida, omita `--flutter`, `--web` e `--python`. O agente faz discovery/research e recomenda uma opção depois do intake. Use somente uma dessas flags por inicialização.

## Fluxo recomendado após o `init`

```text
1. doctor e audit
2. intake status
3. respostas humanas registradas no Charter
4. avaliações técnicas do agente, incluindo princípios
5. aprovação humana do Charter
6. decisão arquitetural quando necessária
7. resolve build e map build
8. classificação L0-L3 da mudança
9. spec/plano para mudanças proporcionais ao risco
10. implementação, testes e validate
11. map check, resolve check e documentação atualizada
```

Comandos típicos:

```powershell
aifw doctor
aifw audit --json
aifw intake status --json
aifw principle review --signals change:behavior,design:modular --write
aifw intake approve --by "human:proprietario"
aifw resolve build
aifw map build
aifw change classify --behavior-change --local-only --reversible
aifw validate --level L1
aifw resolve check
aifw map check
```

O campo `ready` do intake significa “o Charter pode receber aprovação humana”. O campo `complete` significa “decisões humanas e avaliações técnicas do agente estão concluídas”. Você não precisa escolher manualmente SOLID ou Clean Code; o agente deriva sinais, executa a revisão e apresenta findings concretos.

## Ajuda e saída JSON

Para descobrir a sintaxe atual:

```powershell
aifw --help
aifw init --help
aifw route activate --help
```

A referência literal gerada de todos os comandos e opções está em [docs/cli-reference.generated.md](docs/cli-reference.generated.md).

Quase todos os comandos aceitam `--json`. Use essa opção para Pi, scripts e CI, porque a saída é estável e estruturada.

| Código | Significado |
| --- | --- |
| `0` | comando concluído ou verificação aprovada |
| `2` | comando válido, mas estado ainda incompleto, desatualizado ou bloqueado |
| `1` | erro de entrada, contrato, configuração ou execução |

## Referência completa dos comandos

### `aifw init`

Inicializa o AIFW na pasta atual. Cria `aifw.yaml`, `.aifw/`, `PROJECT_MAP.md`, diretórios de documentação e contratos. Recusa sobrescrever um projeto já inicializado.

```powershell
aifw init --id app --name "Projeto" --flutter --existing `
  --locale pt-BR --primary windows --targets windows,wsl,linux-ci
```

Opções principais:

- `--id`: identificador estável, curto e sem espaços;
- `--name`: nome humano do projeto;
- `--existing`: informa que já existe uma base de código;
- `--flutter`, `--web` ou `--python`: profile primário, no máximo um;
- `--primary`: ambiente cotidiano (`windows`, `wsl` ou `linux`);
- `--targets`: ambientes que deverão ser validados;
- `--locale`: idioma dos artefatos do projeto.

### `aifw audit`

Faz discovery somente leitura. Detecta stack, scripts, dependências, CI, contratos, ADRs, estrutura Flutter e freshness do mapa. Não documenta automaticamente responsabilidades sem evidência.

```powershell
aifw audit --json
```

### `aifw intake status`

Mostra perguntas humanas ainda ausentes, unknowns bloqueantes e avaliações pertencentes ao agente.

```powershell
aifw intake status --json
```

Estados da avaliação técnica: `pending`, `current`, `stale` e `invalid`. Retorna código 2 enquanto `complete` for falso.

### `aifw intake approve`

Aprova o Project Charter quando as decisões humanas estão prontas. A identidade deve começar com `human:`. A aprovação não autoriza automaticamente deploy, gastos ou mudanças futuras.

```powershell
aifw intake approve --by "human:proprietario"
```

`--at` permite informar um timestamp ISO-8601; sem ele, a CLI usa o instante atual.

### `aifw map build`

Recompila `PROJECT_MAP.md` a partir de `.aifw/catalog.yaml`. Use após atualizar módulos, relações, contratos ou fontes de verdade.

```powershell
aifw map build
```

### `aifw map check`

Compara o mapa existente com o catálogo sem reescrevê-lo. Retorna código 2 se estiver desatualizado.

```powershell
aifw map check --json
```

### `aifw decision list`

Lista catálogos arquiteturais disponíveis, drivers e alternativas. Profiles ativos podem adicionar categorias.

```powershell
aifw decision list
aifw decision list --category application-architecture
```

### `aifw decision recommend`

Pontua alternativas usando sinais explícitos, mostra conflitos e dúvidas e, com `--write`, persiste um caso revisável.

```powershell
aifw decision recommend `
  --category application-architecture `
  --signals domain:complex,integrations:many,testability:high `
  --write
```

`--selected` informa decisões já adotadas para detectar incompatibilidades. Uma recomendação não equivale a aprovação.

### `aifw decision approve`

Registra a alternativa escolhida depois de revisão humana. Exige um ADR já existente dentro do projeto.

```powershell
aifw decision approve `
  --category application-architecture `
  --option clean-architecture `
  --by "human:proprietario" `
  --adr docs/adr/ADR-0001-architecture.md
```

Use os IDs realmente retornados por `decision list`; o exemplo não garante que uma opção com esse ID exista no profile atual.

### `aifw principle list`

Lista Clean Code, SOLID e princípios fundamentais, incluindo quando se aplicam, perguntas de revisão, evidências, exceções e riscos de mau uso.

```powershell
aifw principle list
aifw principle list --family solid
```

Famílias aceitas: `clean-code`, `solid` e `foundational`.

### `aifw principle review`

Gera uma revisão contextual. Os sinais devem vir da descoberta do agente, não de uma tentativa de ativar todos os princípios.

```powershell
aifw principle review `
  --signals change:behavior,design:modular,artifact:tests `
  --write
```

`--write` grava `.aifw/reviews/engineering-principles.json`, usado por `intake status` para determinar se a avaliação está atual.

### `aifw resolve build`

Resolve Constitution/core, defaults pessoais opcionais, profiles e regras do projeto. Grava `.aifw/effective-policy.json` e `.aifw/framework.lock.yaml`.

```powershell
aifw resolve build
aifw resolve build --personal "C:\caminho\para\personal-policy.yaml"
```

### `aifw resolve check`

Verifica sem escrever se a policy efetiva e o lock continuam atuais.

```powershell
aifw resolve check --json
```

### `aifw change classify`

Classifica impacto L0–L3 e informa artefatos, gates e rota cognitiva sugerida.

```powershell
aifw change classify --read-only
aifw change classify --docs-only --local-only --reversible
aifw change classify --behavior-change --local-only --reversible
aifw change classify --shared-contract --cross-module
aifw change classify --touches-auth --security-boundary
```

Sinais disponíveis:

- baixo impacto: `--read-only`, `--docs-only`, `--local-only`, `--reversible`;
- estrutural: `--behavior-change`, `--cross-module`, `--shared-contract`, `--global-design-system`;
- risco: `--sensitive-data`, `--external-cost`, `--production`, `--touches-auth`;
- crítico: `--framework-core`, `--constitution`, `--security-boundary`, `--destructive-migration`, `--breaking-contract`, `--irreversible-production`;
- complexidade independente do impacto: `--complexity fast|work|brain`.

### `aifw route explain`

Explica qual rota FAST/WORK/BRAIN é apropriada. Na CLI, este comando não troca o modelo do Pi.

```powershell
aifw route explain `
  --impact L2 `
  --operation implementation `
  --uncertainty medium `
  --failed-attempts 0
```

Operações: `single-read`, `discovery`, `documentation`, `implementation`, `review`, `research`, `architecture-decision` e `incident-response`. Use `--cross-domain` quando a tarefa atravessar domínios relevantes.

### `aifw route status`

Mostra a policy persistida, aliases, modelos-alvo, modo e evidência de ativação do projeto atual.

```powershell
aifw route status --json
```

Projetos novos começam em `recommendation-only`, mesmo que a configuração pessoal do Pi tenha roteamento automático.

### `aifw route eval`

Executa os casos determinísticos de roteamento e calcula se o relatório atende aos mínimos para ativação.

```powershell
aifw route eval --output .aifw/routing-report.json --json
```

`--cases` permite fornecer outra fixture revisável. Falhas retornam código 2.

### `aifw route activate`

Ativa o roteamento automático somente depois de relatório aprovado e registro humano persistido.

```powershell
aifw route activate `
  --report .aifw/routing-report.json `
  --by "human:proprietario" `
  --record docs/adr/ADR-0008-routing.md
```

Não execute isso apenas para “ligar uma opção”: a ativação exige pelo menos 30 casos, 95% de aprovação, nenhuma falha crítica e evidência humana.

### `aifw handoff codex`

Gera um Markdown redigido e autocontido para transferência manual ao Codex. Não envia nada automaticamente.

```powershell
aifw handoff codex `
  --input .aifw/codex-handoff-input.json `
  --output .aifw/handoffs/blocker.md
```

O JSON de entrada segue `schemas/codex-handoff.schema.json`; existe um exemplo em `templates/codex-handoff-input.json`.

### `aifw doctor`

Verifica Node, Git, Windows e WSL. WSL é tratado como ambiente separado; indisponibilidade do WSL não é confundida com falha do Node no Windows.

```powershell
aifw doctor --json
```

### `aifw eval`

Executa casos de conformidade comportamental contra traces do agente. Serve para verificar se o agente respeita ordem, aprovações, evidências e comportamentos proibidos.

```powershell
aifw eval --json
aifw eval --cases evals/cases --traces evals/traces
```

Este comando é diferente de `route eval`: um testa comportamento geral do agente; o outro testa especificamente decisões de roteamento.

### `aifw validate`

Executa os quality gates selecionados para o nível de impacto.

```powershell
aifw validate --level L0
aifw validate --level L1
aifw validate --level L2
aifw validate --level L3
```

- L0: verificações mecânicas proporcionais;
- L1: mudança local e reversível;
- L2: feature, módulo ou contrato compartilhado;
- L3: arquitetura, autenticação, segurança, framework ou mudança crítica.

Gate obrigatório ausente ou sem evidência bloqueia; não vira aprovação implícita.

## Comandos e ferramentas dentro do Pi

Esses itens vêm da extensão do AIFW e não são subcomandos da CLI:

### `/aifw-routing`

Mostra o modo de roteamento, modelo atual e alvos FAST/WORK/BRAIN.

### `/aifw-route`

Classifica e, somente quando a policy permite, troca o modelo:

```text
/aifw-route L2 implementation medium 0
```

O último número é a quantidade de tentativas anteriores. Exemplo crítico:

```text
/aifw-route L3 architecture-decision high 2
```

### `/codex-handoff`

Pede ao Pi para reunir o bloqueio e gerar um handoff manual:

```text
/codex-handoff corrigir o bloqueio de autenticação sem alterar o contrato público
```

Depois revise o Markdown em `.aifw/handoffs/` e entregue-o ao Codex.

### `aifw_route_task`

Ferramenta usada pelo próprio agente antes de trabalho não trivial. Classifica impacto, operação e incerteza e respeita a policy persistida.

### `aifw_codex_handoff`

Ferramenta estruturada usada pelo agente para criar o arquivo de handoff com erros exatos, tentativas distintas, evidências, arquivos relevantes, restrições e critérios de verificação.

## O que você precisa decidir e o que o agente decide

Você decide:

- problema, público e resultado esperado;
- o que entra e o que fica fora;
- restrições, dados, riscos e custos;
- autonomia para Git, serviços, preview e produção;
- preferências ou proibições técnicas que realmente existam;
- aprovação de Charter, ADRs e mudanças críticas.

O agente descobre ou recomenda:

- stack quando não foi determinada;
- arquitetura e padrões adequados ao contexto;
- quais princípios são aplicáveis;
- nível L0–L3 e rota FAST/WORK/BRAIN;
- testes, gates, documentação e evidências necessárias.

## Arquivos que você consultará com mais frequência

| Arquivo | Função |
| --- | --- |
| `PROJECT_MAP.md` | entrada rápida para humano ou IA |
| `.aifw/charter.yaml` | decisões do início do projeto |
| `aifw.yaml` | versão, ambientes e profiles |
| `.aifw/catalog.yaml` | fatos que geram o mapa |
| `.aifw/effective-policy.json` | regras efetivas compiladas |
| `.aifw/framework.lock.yaml` | versões e digests fixados |
| `.aifw/gates.yaml` | quality gates |
| `.aifw/permissions.yaml` | autonomia e efeitos colaterais |
| `.aifw/routing.yaml` | política de roteamento do projeto |
| `docs/adr/` | decisões arquiteturais persistidas |
| `.aifw/handoffs/` | transferências manuais para Codex |

## Manutenção deste guia

`npm run docs:generate` percorre recursivamente a árvore real de `--help` e atualiza `docs/cli-reference.generated.md`. `npm run docs:check` compara o arquivo versionado com a CLI e falha se qualquer comando, opção ou descrição estiver desatualizado. O `HOW_TO_USE.md` permanece a explicação humana e precisa ser revisado quando o significado ou o fluxo de um comando mudar.

Antes de publicar ou distribuir uma atualização:

```powershell
npm run check
npm run build
aifw map check
```
