# Plano técnico: nome da mudança

## Entradas aprovadas

Charter outcome, spec, Change Case, ADRs, contratos e policies aplicáveis.

## Descoberta atual

Estrutura existente, comandos verificados, owners, dependências e limitações. Diferencie fato de inferência.

## Design

Componentes/módulos, boundaries, fluxo de dados, interfaces e decisões. Referencie diagramas C4.

## Sequência de implementação

Para cada etapa: arquivos/módulos, comportamento, teste primeiro, rollback local e dependências.

## Contratos e migração

Mudanças compatíveis/incompatíveis, versionamento, dual read/write, backfill, cutover e rollback.

## Segurança e privacidade

Threat model, authorization, validation, secrets, dados, abuse/rate limit e supply chain.

## UI e design system

Tokens, componentes, estados, responsividade, acessibilidade, Storybook e visual regression. Exceções têm rule ID/waiver.

## Observabilidade e operação

Sinais, dashboards, alertas, runbooks, rollout e critérios de abortar.

## Testes e gates

Unit, integration, contract, E2E, visual, accessibility, performance e conformance selecionados pelo risco.

## Rollout/rollback

Checkpoint, feature flag, preview/staging, canary, produção, responsáveis e verificação pós-deploy.

## Documentação afetada

ADR, PROJECT_MAP/catalog, OpenAPI/AsyncAPI, policies/profiles, runbooks e release/migration notes.
