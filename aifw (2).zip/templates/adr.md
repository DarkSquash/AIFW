# ADR-NNNN: Título da decisão

- Status: proposed | accepted | superseded | rejected
- Date: YYYY-MM-DD
- Owners: human:owner
- Change level: L2 | L3
- Supersedes: none

## Contexto

Problema, restrições, fatos verificados, unknowns e por que a decisão precisa ser tomada agora.

## Drivers

- necessidade mensurável;
- segurança/compliance;
- custo e operação;
- compatibilidade/migração;
- experiência do usuário/desenvolvedor.

## Opções consideradas

### Opção A

Descrição, vantagens, desvantagens, riscos e evidência.

### Opção B

Descrição, vantagens, desvantagens, riscos e evidência.

## Decisão

Escolha e escopo exato. Especifique o que não foi decidido.

## Consequências

Positivas, negativas, dívida aceita, custo, observabilidade, segurança e manutenção.

## Plano de adoção e rollback

Etapas, compatibilidade, migration, flags/checkpoints, critério de abortar e recuperação.

## Validação

Testes, gates, métricas e revisão que provarão a decisão.

## Artefatos afetados

Policies, profiles, schemas, contratos, C4, PROJECT_MAP, runbooks e docs.

## Aprovação

- Approved by:
- Approved at:
- Content/reference digest:
