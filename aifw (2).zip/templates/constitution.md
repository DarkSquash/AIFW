# Project Constitution additions

Este arquivo pode acrescentar invariantes do domínio, mas não enfraquece `CONSTITUTION.md` nem `policies/core.yaml`.

Para cada regra: ID, versão, MUST/MUST_NOT/SHOULD/MAY, escopo, justificativa, owner, enforcement, evidência e se é substituível. Alteração exige Change Case L3, ADR e aprovação humana.
