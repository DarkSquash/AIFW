# Threat model: nome do fluxo

## Escopo e assets

Dados, identities, secrets, disponibilidade e decisões protegidas.

## Diagrama e trust boundaries

Referencie C4/data flow; marque entrada não confiável, serviços externos e stores.

## Actors

Usuários legítimos, admins, serviços, insiders e atacantes relevantes.

## STRIDE

| ID | Categoria | Cenário | Impacto | Controle | Evidência | Risco residual | Owner |
| --- | --- | --- | --- | --- | --- | --- | --- |
| T-001 | Spoofing | ... | ... | ... | ... | ... | ... |

Cubra Spoofing, Tampering, Repudiation, Information disclosure, Denial of service e Elevation of privilege ou explique por que não se aplicam.

## Abuse cases

Automação, scraping, enumeração, bypass de tenant, upload malicioso, replay, race e custo induzido.

## Decisão e aprovação

Riscos aceitos, mitigados ou transferidos; approver, instante, Change Case/ADR e revisão futura.
