# Spec: nome da capability

## Metadados

- ID:
- Charter outcome:
- Change level:
- Owner:
- Status: draft | approved | implemented | verified

## Problema e resultado

Quem tem qual problema, qual mudança observável esperamos e como ela apoia o Charter.

## Escopo

### Incluído

- ...

### Excluído

- ...

## Requisitos funcionais

Use IDs estáveis (`FR-001`) e linguagem testável.

## Requisitos não funcionais

Acessibilidade, performance, segurança, privacidade, disponibilidade, compatibilidade, localização e custo.

## Jornadas e estados

Happy path, vazio, loading, erro, permissão negada, retry, offline/timeout e estados limites.

## Contratos

Referências OpenAPI/AsyncAPI/eventos/schemas, compatibilidade e consumidores conhecidos.

## Dados e autorização

Entidades, classificação, retenção, acesso por papel/tenant, auditabilidade e migrations.

## Observabilidade

SLIs/SLOs, métricas, logs/traces sanitizados e alertas acionáveis.

## Critérios de aceitação

- [ ] Given/When/Then ou condição objetiva.

## Riscos e unknowns

| Item | Impacto | Como validar | Blocking |
| --- | --- | --- | --- |

## Evidência e aprovação

Fontes pesquisadas, protótipos, decisões relacionadas, approver, instante e digest.
