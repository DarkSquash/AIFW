# Plano de observabilidade: fluxo

## Resultado e SLO

- user journey:
- SLI:
- target/window:
- error budget:
- owner:

## Métricas

Nome, unidade, labels limitadas, fonte, cardinalidade, dashboard e threshold.

## Logs

Eventos estruturados, correlation ID, níveis, redaction, retenção e exemplos sem dados sensíveis.

## Traces

Spans e boundaries, sampling, baggage permitido e ligação com logs/métricas.

## Alertas

Condição acionável, duração, severidade, destinatário, dedupe e runbook.

## Validação

Como provocar sinal em ambiente seguro, provar dashboard/alerta e verificar ausência de secrets/PII.

## Rollout e custo

Baseline, mudança esperada, limite de ingestão/cardinalidade e condição de rollback.
