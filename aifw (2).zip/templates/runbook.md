# Runbook: condição operacional

- Owner:
- Service/catalog ID:
- Severity:
- Last verified:
- Related dashboards/alerts:

## Trigger e sintomas

Sinal que inicia o runbook e como confirmar impacto real.

## Segurança e prerequisites

Acessos, approval policy, dados protegidos, checkpoint e ações proibidas.

## Diagnóstico

Passos somente leitura primeiro, resultado esperado e ramificações.

## Mitigação

Ação reversível de menor impacto, validação e tempo limite.

## Rollback/recovery

Comandos/ações, aprovação exigida, preservação de dados e como provar recuperação.

## Escalada e comunicação

Quando parar, quem chamar e o que comunicar sem expor secrets.

## Pós-incidente

Timeline/evidências, causa, gaps de detecção, ações com owner/prazo e atualização de testes/policies/docs.
